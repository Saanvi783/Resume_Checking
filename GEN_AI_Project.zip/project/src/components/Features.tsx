import React from 'react';
import { Brain, Target, Award, TrendingUp, CheckCircle, Users, Zap, Shield } from 'lucide-react';

const Features = () => {
  const features = [
    {
      icon: <Brain className="h-8 w-8 text-blue-600" />,
      title: "AI-Powered Analysis",
      description: "Advanced machine learning algorithms analyze your resume's content, structure, and effectiveness against industry standards.",
      color: "bg-blue-50",
      borderColor: "border-blue-200"
    },
    {
      icon: <Target className="h-8 w-8 text-green-600" />,
      title: "ATS Optimization",
      description: "Ensure your resume passes Applicant Tracking Systems with keyword optimization and formatting recommendations.",
      color: "bg-green-50",
      borderColor: "border-green-200"
    },
    {
      icon: <Award className="h-8 w-8 text-purple-600" />,
      title: "Industry Insights",
      description: "Get tailored recommendations based on your target industry, role, and current market trends.",
      color: "bg-purple-50",
      borderColor: "border-purple-200"
    },
    {
      icon: <TrendingUp className="h-8 w-8 text-orange-600" />,
      title: "Performance Scoring",
      description: "Receive detailed scoring across multiple dimensions including content quality, formatting, and keyword density.",
      color: "bg-orange-50",
      borderColor: "border-orange-200"
    },
    {
      icon: <Zap className="h-8 w-8 text-yellow-600" />,
      title: "Instant Feedback",
      description: "Get real-time suggestions and improvements as you upload your resume - no waiting required.",
      color: "bg-yellow-50",
      borderColor: "border-yellow-200"
    },
    {
      icon: <Shield className="h-8 w-8 text-indigo-600" />,
      title: "Privacy Protected",
      description: "Your resume data is processed securely and never stored on our servers. Complete privacy guaranteed.",
      color: "bg-indigo-50",
      borderColor: "border-indigo-200"
    }
  ];

  return (
    <section id="features" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center bg-blue-50 rounded-full px-4 py-2 border border-blue-200 mb-4">
            <CheckCircle className="h-4 w-4 text-blue-600 mr-2" />
            <span className="text-sm font-medium text-blue-700">Powerful Features</span>
          </div>
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
            Everything You Need to 
            <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent"> Perfect Your Resume</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Our comprehensive AI-powered platform provides deep insights and actionable recommendations 
            to help you create a resume that stands out to employers and passes through ATS systems.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div key={index} className={`group hover:shadow-xl transition-all duration-300 rounded-2xl p-8 border-2 ${feature.borderColor} ${feature.color} hover:scale-105`}>
              <div className="bg-white rounded-xl p-4 w-fit mb-6 shadow-sm">
                {feature.icon}
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">
                {feature.title}
              </h3>
              <p className="text-gray-600 leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>

        <div className="mt-16 bg-gradient-to-r from-blue-600 to-purple-600 rounded-3xl p-8 text-center text-white">
          <h3 className="text-2xl font-bold mb-4">Ready to Transform Your Resume?</h3>
          <p className="text-blue-100 mb-6 max-w-2xl mx-auto">
            Join thousands of successful job seekers who have improved their resumes with our AI-powered analysis.
          </p>
          <button className="bg-white text-blue-600 px-8 py-3 rounded-xl font-semibold hover:shadow-lg transition-all duration-200">
            Start Free Analysis
          </button>
        </div>
      </div>
    </section>
  );
};

export default Features;