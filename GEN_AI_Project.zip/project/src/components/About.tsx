import React from 'react';
import { Brain, Award, Users, Zap } from 'lucide-react';

const About = () => {
  const stats = [
    {
      number: "100K+",
      label: "Resumes Analyzed",
      icon: <Users className="h-8 w-8 text-blue-600" />
    },
    {
      number: "95%",
      label: "Success Rate",
      icon: <Award className="h-8 w-8 text-green-600" />
    },
    {
      number: "30+",
      label: "Industries Covered",
      icon: <Zap className="h-8 w-8 text-purple-600" />
    },
    {
      number: "24/7",
      label: "AI Processing",
      icon: <Brain className="h-8 w-8 text-orange-600" />
    }
  ];

  return (
    <section id="about" className="py-20 bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-4xl font-bold mb-6">
              Powered by IBM Watson AI
            </h2>
            <p className="text-xl text-gray-300 mb-6 leading-relaxed">
              Our resume analysis platform leverages IBM Watson's advanced natural language processing 
              and machine learning capabilities to provide you with intelligent, actionable insights.
            </p>
            <p className="text-lg text-gray-400 mb-8 leading-relaxed">
              Developed as part of IBM's Generative AI course, this tool represents the cutting edge 
              of AI-powered career development technology. We analyze patterns from thousands of 
              successful resumes to help you optimize your professional presentation.
            </p>
            
            <div className="grid grid-cols-2 gap-6">
              {stats.map((stat, index) => (
                <div key={index} className="text-center">
                  <div className="inline-flex p-3 bg-gray-800 rounded-lg mb-3">
                    {stat.icon}
                  </div>
                  <div className="text-3xl font-bold text-white mb-1">{stat.number}</div>
                  <div className="text-sm text-gray-400">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
          
          <div className="bg-gray-800 rounded-2xl p-8">
            <h3 className="text-2xl font-semibold mb-6">Why Choose ResumeAI?</h3>
            <div className="space-y-4">
              <div className="flex items-start">
                <div className="bg-blue-600 rounded-full w-2 h-2 mt-2 mr-3"></div>
                <div>
                  <h4 className="font-semibold text-white mb-1">Enterprise-Grade AI</h4>
                  <p className="text-gray-400 text-sm">
                    Built on IBM Watson's proven enterprise AI platform used by Fortune 500 companies
                  </p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="bg-green-600 rounded-full w-2 h-2 mt-2 mr-3"></div>
                <div>
                  <h4 className="font-semibold text-white mb-1">Data-Driven Insights</h4>
                  <p className="text-gray-400 text-sm">
                    Our recommendations are based on analysis of successful hiring patterns
                  </p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="bg-purple-600 rounded-full w-2 h-2 mt-2 mr-3"></div>
                <div>
                  <h4 className="font-semibold text-white mb-1">Privacy First</h4>
                  <p className="text-gray-400 text-sm">
                    Your resume data is processed securely and never stored on our servers
                  </p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="bg-orange-600 rounded-full w-2 h-2 mt-2 mr-3"></div>
                <div>
                  <h4 className="font-semibold text-white mb-1">Continuous Learning</h4>
                  <p className="text-gray-400 text-sm">
                    Our AI model constantly improves based on job market trends and feedback
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;