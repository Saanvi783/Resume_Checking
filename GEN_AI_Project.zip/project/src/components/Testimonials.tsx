import React from 'react';
import { Star, Quote } from 'lucide-react';

const Testimonials = () => {
  const testimonials = [
    {
      name: "Sarah Chen",
      role: "Software Engineer",
      company: "Google",
      image: "https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop",
      content: "ResumeCheck Pro helped me identify key improvements that I never would have noticed. I got 3x more interview calls after optimizing my resume with their suggestions.",
      rating: 5
    },
    {
      name: "Michael Rodriguez",
      role: "Marketing Manager",
      company: "HubSpot",
      image: "https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop",
      content: "The ATS optimization feature is incredible. My resume was getting filtered out before, but now it passes through every system. Landed my dream job in 2 weeks!",
      rating: 5
    },
    {
      name: "Emily Johnson",
      role: "Data Scientist",
      company: "Microsoft",
      image: "https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop",
      content: "The industry-specific insights were game-changing. The AI understood exactly what tech recruiters look for and helped me highlight the right skills and experiences.",
      rating: 5
    },
    {
      name: "David Park",
      role: "Product Manager",
      company: "Airbnb",
      image: "https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop",
      content: "I was skeptical about AI resume checking, but the detailed feedback was more thorough than any human reviewer I've worked with. Highly recommend!",
      rating: 5
    },
    {
      name: "Lisa Thompson",
      role: "UX Designer",
      company: "Adobe",
      image: "https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop",
      content: "The real-time feedback feature saved me hours of back-and-forth revisions. I could see improvements instantly as I made changes to my resume.",
      rating: 5
    },
    {
      name: "James Wilson",
      role: "Sales Director",
      company: "Salesforce",
      image: "https://images.pexels.com/photos/1212984/pexels-photo-1212984.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop",
      content: "The performance scoring helped me understand exactly where my resume was weak. After implementing the suggestions, my response rate increased by 400%.",
      rating: 5
    }
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
            Loved by Job Seekers Worldwide
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Join thousands of professionals who have transformed their careers with our AI-powered resume analysis.
          </p>
          <div className="flex items-center justify-center space-x-2 mt-6">
            <div className="flex space-x-1">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
              ))}
            </div>
            <span className="text-gray-600 font-medium">4.9/5 from 10,000+ reviews</span>
          </div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="bg-white rounded-2xl p-8 shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-300">
              <div className="flex items-center mb-6">
                <img 
                  src={testimonial.image} 
                  alt={testimonial.name}
                  className="w-12 h-12 rounded-full object-cover mr-4"
                />
                <div>
                  <h4 className="font-semibold text-gray-900">{testimonial.name}</h4>
                  <p className="text-sm text-gray-600">{testimonial.role} at {testimonial.company}</p>
                </div>
              </div>

              <div className="flex space-x-1 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="h-4 w-4 text-yellow-400 fill-current" />
                ))}
              </div>

              <div className="relative">
                <Quote className="h-6 w-6 text-gray-300 absolute -top-2 -left-1" />
                <p className="text-gray-700 leading-relaxed pl-6">
                  {testimonial.content}
                </p>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 bg-gradient-to-r from-blue-600 to-purple-600 rounded-3xl p-8 text-center text-white">
          <h3 className="text-3xl font-bold mb-4">Ready to Join Them?</h3>
          <p className="text-blue-100 mb-6 text-lg max-w-2xl mx-auto">
            Start your journey to landing your dream job with our AI-powered resume analysis.
          </p>
          <button className="bg-white text-blue-600 px-8 py-4 rounded-xl font-semibold hover:shadow-lg transition-all duration-200 text-lg">
            Analyze Your Resume Now
          </button>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;