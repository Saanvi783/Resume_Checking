import React from 'react';
import { Upload, Search, Lightbulb, Download, ArrowRight } from 'lucide-react';

const HowItWorks = () => {
  const steps = [
    {
      number: "01",
      icon: <Upload className="h-8 w-8 text-blue-600" />,
      title: "Upload Resume",
      description: "Simply drag and drop your resume file or click to browse. We support PDF, DOC, and DOCX formats up to 10MB.",
      color: "bg-blue-50",
      borderColor: "border-blue-200"
    },
    {
      number: "02",
      icon: <Search className="h-8 w-8 text-green-600" />,
      title: "AI Analysis",
      description: "Our advanced AI analyzes your resume's content, structure, keywords, ATS compatibility, and industry alignment.",
      color: "bg-green-50",
      borderColor: "border-green-200"
    },
    {
      number: "03",
      icon: <Lightbulb className="h-8 w-8 text-purple-600" />,
      title: "Get Insights",
      description: "Receive detailed feedback with actionable suggestions, performance scores, and specific recommendations for improvement.",
      color: "bg-purple-50",
      borderColor: "border-purple-200"
    },
    {
      number: "04",
      icon: <Download className="h-8 w-8 text-orange-600" />,
      title: "Optimize & Apply",
      description: "Apply the recommendations, download your improved resume, and start applying to jobs with confidence.",
      color: "bg-orange-50",
      borderColor: "border-orange-200"
    }
  ];

  return (
    <section id="how-it-works" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
            How It Works
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Our streamlined process makes it easy to get professional insights on your resume 
            in just four simple steps. No registration required.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 relative">
          {steps.map((step, index) => (
            <div key={index} className="relative">
              <div className={`text-center p-8 rounded-2xl border-2 ${step.borderColor} ${step.color} hover:shadow-lg transition-all duration-300`}>
                <div className="relative mb-6">
                  <div className="bg-white rounded-2xl p-4 w-fit mx-auto shadow-sm">
                    {step.icon}
                  </div>
                  <div className="absolute -top-2 -right-2 bg-gray-900 text-white text-sm font-bold rounded-full w-8 h-8 flex items-center justify-center">
                    {step.number}
                  </div>
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-4">
                  {step.title}
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  {step.description}
                </p>
              </div>
              
              {index < steps.length - 1 && (
                <div className="hidden lg:block absolute top-1/2 -right-4 transform -translate-y-1/2 z-10">
                  <ArrowRight className="h-6 w-6 text-gray-400" />
                </div>
              )}
            </div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <div className="bg-white rounded-2xl p-8 shadow-lg border border-gray-200 max-w-2xl mx-auto">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">
              Average Analysis Time: 15 seconds
            </h3>
            <p className="text-gray-600 mb-6">
              Our AI processes your resume instantly, providing comprehensive feedback faster than any human reviewer.
            </p>
            <button className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-8 py-3 rounded-xl font-semibold hover:shadow-lg transition-all duration-200">
              Try It Now - It's Free
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;