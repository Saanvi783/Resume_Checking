import React from 'react';
import { BarChart3, AlertCircle, CheckCircle, TrendingUp, Star } from 'lucide-react';

const ResultsDemo = () => {
  const analysisResults = [
    {
      category: "ATS Compatibility",
      score: 92,
      status: "excellent",
      icon: <CheckCircle className="h-5 w-5 text-green-500" />,
      feedback: "Resume structure is highly compatible with ATS systems"
    },
    {
      category: "Keyword Optimization",
      score: 78,
      status: "good",
      icon: <TrendingUp className="h-5 w-5 text-blue-500" />,
      feedback: "Good keyword usage, consider adding 3-5 more relevant terms"
    },
    {
      category: "Content Quality",
      score: 85,
      status: "good",
      icon: <Star className="h-5 w-5 text-purple-500" />,
      feedback: "Strong content with quantifiable achievements"
    },
    {
      category: "Formatting",
      score: 67,
      status: "needs-improvement",
      icon: <AlertCircle className="h-5 w-5 text-orange-500" />,
      feedback: "Consider improving section spacing and bullet point consistency"
    }
  ];

  const suggestions = [
    "Add 2-3 more industry-specific keywords in your skills section",
    "Include quantifiable results in your work experience bullets",
    "Standardize your bullet point formatting throughout",
    "Add a professional summary section at the top",
    "Consider reducing white space between sections"
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Sample Analysis Results
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            See the kind of detailed insights and actionable feedback you'll receive 
            from our Watson AI analysis.
          </p>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-12">
          <div className="bg-gray-50 rounded-2xl p-8">
            <div className="flex items-center mb-6">
              <BarChart3 className="h-6 w-6 text-blue-600 mr-3" />
              <h3 className="text-2xl font-semibold text-gray-900">Performance Metrics</h3>
            </div>
            
            <div className="space-y-6">
              {analysisResults.map((result, index) => (
                <div key={index} className="bg-white rounded-lg p-4 border border-gray-200">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center">
                      {result.icon}
                      <span className="font-medium text-gray-900 ml-2">{result.category}</span>
                    </div>
                    <span className="text-2xl font-bold text-gray-900">{result.score}/100</span>
                  </div>
                  
                  <div className="w-full bg-gray-200 rounded-full h-2 mb-2">
                    <div 
                      className={`h-2 rounded-full ${
                        result.score >= 90 ? 'bg-green-500' : 
                        result.score >= 80 ? 'bg-blue-500' : 
                        result.score >= 70 ? 'bg-purple-500' : 
                        'bg-orange-500'
                      }`}
                      style={{ width: `${result.score}%` }}
                    ></div>
                  </div>
                  
                  <p className="text-sm text-gray-600">{result.feedback}</p>
                </div>
              ))}
            </div>
          </div>
          
          <div className="bg-blue-50 rounded-2xl p-8">
            <h3 className="text-2xl font-semibold text-gray-900 mb-6">
              AI-Powered Suggestions
            </h3>
            
            <div className="space-y-4">
              {suggestions.map((suggestion, index) => (
                <div key={index} className="bg-white rounded-lg p-4 border border-blue-200">
                  <div className="flex items-start">
                    <div className="bg-blue-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold mr-3 mt-0.5">
                      {index + 1}
                    </div>
                    <p className="text-gray-700 flex-1">{suggestion}</p>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="mt-8 p-4 bg-blue-100 rounded-lg">
              <p className="text-sm text-blue-800">
                <strong>Pro Tip:</strong> Implementing these suggestions could increase your resume's 
                effectiveness by up to 40% based on our analysis of successful job applications.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ResultsDemo;